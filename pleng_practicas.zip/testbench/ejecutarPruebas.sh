#!/bin/bash
 

java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/cambio_base.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/conjetura_goldbach.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/criba_eratostenes.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/factorial.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/fibonacci_iterativo.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/fibonacci.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/hello_world.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/juego_de_la_vida.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/max.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/mcd.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/numero_euler.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/numero_pi_leibnitz.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/quicksort.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/reinas_ajedrez.adac
java -jar adac.jar /home/gabete/PLeng/Practicas/pleng21-22/doc/xamples/torres_de_hanoi.adac
