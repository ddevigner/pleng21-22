Práctica 2: Construcción de un analizador sintactico para "adac"
Blah, blah, blah

Para la recuperacion de errores se ha optado por el metodo en modo panico en d
os niveles, un primer nivel por instruccion (;) y otro superior a nivel de 
bloque (end).

Sergio Gabete César (774631) & Devid Dokash (780131).
