Calculador calc_enteros.jar (V1.0)
----------------------------------
Implementa una calculadora sencilla de números enteros, que permite definir variables y constantes.


Invocar como:

-------------------------------------------------------------
java -jar calc_enteros.jar [fichero de instrucciones]
-------------------------------------------------------------

Si se invoca sin parámetros, lee la entrada estándar.