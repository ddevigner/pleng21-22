//*****************************************************************
// File:   wc.jj
// Author: Procesadores de Lenguajes-University of Zaragoza
// Date:   febrero 2022
// Coms:   Compilar mediante "ant"
//         Implementa una versión sin opcines del "wc" de Unix
//         La gramática está formada por una única producción
//         Respecto a la versión 1, la información que modifica el 
//         parser está en un objeto (de una clase definida en lib)
//         y generado en el main, y que se pasa como parámetro
//*****************************************************************
