//*****************************************************************
// File:   InfoFich.java
// Author: Procesadores de Lenguajes-University of Zaragoza
// Date:   febrero 2022
// Coms:   
//*****************************************************************

package lib.InfoFich;

public class InfoFich {
	public int nPal = 0, nLin = 0, nChar = 0;

	public String toString() {
		return nLin + "\t" + nPal + "\t" + nChar;
	}
}