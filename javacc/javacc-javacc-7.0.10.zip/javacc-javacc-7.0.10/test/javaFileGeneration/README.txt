Tests the contents of the near bolier-plate Java Files, created by
JavaFiles.java.
