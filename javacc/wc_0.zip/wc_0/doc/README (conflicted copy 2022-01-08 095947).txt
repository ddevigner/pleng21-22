//*****************************************************************
// File:   wc.jj
// Author: Procesadores de Lenguajes-University of Zaragoza
// Date:   febrero 2022
// Coms:   Compilar mediante "ant"
//         Implementa una versión sin opcines del "wc" de Unix
//         La gramática está formdada por una única producción
//         Utiliza variables globales, definidas en la sección
//         TOKEN_MGR_DECLS
//*****************************************************************
