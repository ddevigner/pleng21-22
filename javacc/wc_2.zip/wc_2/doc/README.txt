//*****************************************************************
// File:   wc.jj
// Author: Procesadores de Lenguajes-University of Zaragoza
// Date:   febrero 2022
// Coms:   Compilar mediante "ant"
//         Implementa una versión sin opcines del "wc" de Unix
//         La gramática está formdada por una única producción
//         Respecto a la versión 0, la información que modifica el 
//         parser está en un objeto (de una clase definida en lib)
//         y generada en la producción inicial, que devuelve finalmente
//         dicho objeto.
//         Esta opción no sería válida si la información tuviera que
//         ser compartida entre varias producciones
//*****************************************************************
